<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
              여행정보
              <?php if(Auth::user() -> name == 'admin'): ?> <div class="card-header"><a href="<?php echo e(route('post.index')); ?>" class="btn btn-primary">관리자 페이지 가기</a> </div>
            <?php else: ?> <div class="card-header"><a href="<?php echo e(route('post.index')); ?>" class="btn btn-primary">게시판 가기</a> </div>
            <?php endif; ?>
            <div class="card-body">
                <?php if(session('status')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
                <?php endif; ?>
                <!-- <?php echo e(Auth::user()->name); ?> --> <!-- 로그인한 사용자아이디 -->
                <?php if(Auth::user() -> name == 'admin'): ?> admin 관리자님 환영합니다. <?php else: ?> 환영합니다. <?php endif; ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>