<?php $__env->startSection('content'); ?>
<h2>글 수정</h2>
	<form method="post" action=" <?php echo e(route('post.update', $post->id)); ?> ">
		<?php echo csrf_field(); ?>

		<input type="hidden" name="_method" value="put">
		<div class="form-group">
			<label name="title" for="title">제목</label>
			<input type="text" name="title" class="form-control" value="<?php echo e($post->title); ?>">
		</div>
		<div class="form-group">
			<label name="body" for="body">내용</label>
			<textarea name="body" class="form-control"><?php echo e($post->body); ?></textarea>
		</div>
		<div class="form-group" style="text-align: center;">
			<input type="submit" value="수정하기" class="btn btn-primary">
		</div>
	</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>