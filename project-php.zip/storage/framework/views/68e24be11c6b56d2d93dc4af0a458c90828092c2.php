<?php $__env->startSection('content'); ?>
<hr>
<div style="text-align: center;"><h1>여행정보 글 목록</h1></div>
<hr>
	<ul class="list-group">
		<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li class="list-group-item">
				<a href="<?php echo e(route('post.show', $post->id)); ?>"><?php echo e($post->title); ?>>
			</li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</ul>
	<?php echo $posts -> render(); ?>

	<br><br>
	<h3>
	<div style="text-align: center;"><a href="<?php echo e(route('post.create')); ?>" class="btn btn-primary">글작성</a></div>
</h3>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>