<?php $__env->startSection('content'); ?>
<hr>
	<div style="padding-left: 10%;"> <h1>[제목] </h1><h1><?php echo e($post -> title); ?></h1></div>
	<hr>
	<article>
		<div style="padding-left: 10%;"><h1>[내용] </h1><?php echo e($post->body); ?></div>
	</article>
	<hr><br><br><br><br><br>
	<article>
		<!-- <?php echo e($post->thumbnail); ?> -->
	</article>

	<h3>
		<div style="padding-left: 10%; float: left; width: 33%;"><a href="<?php echo e(route('post.edit', $post->id)); ?>" class="btn btn-primary">글 수정</a></div>
		<form method="post" action="<?php echo e(route('post.destroy', $post->id)); ?>">
			<?php echo csrf_field(); ?>

			<?php echo e(method_field('DELETE')); ?>

			<div style="padding-left: 10%;float: left; width: 33%;"><button class="btn btn-primary" value=""/>글 삭제</button></div>
		</form>

		<div style="padding-left: 10%;float: left; width: 33%;"><a href="<?php echo e(route('post.index')); ?>" class="btn btn-primary">목록으로</a></div>
	</h3>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>